
  # TEENURE App Design

  This is a code bundle for TEENURE App Design. The original project is available at https://www.figma.com/design/74tHmSAnfF3oZhREWToZZ6/TEENURE-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  