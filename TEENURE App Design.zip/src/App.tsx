import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import LandingPage from './components/LandingPage';
import AuthPage from './components/AuthPage';
import StudentDashboard from './components/StudentDashboard';
import TeacherDashboard from './components/TeacherDashboard';
import CareerQuiz from './components/CareerQuiz';
import ExploreOpportunities from './components/ExploreOpportunities';
import CalmZone from './components/CalmZone';
import ProfilePage from './components/ProfilePage';
import CommunityPage from './components/CommunityPage';
import BottomNavigation from './components/BottomNavigation';
import SideNavigation from './components/SideNavigation';
import './styles/globals.css';

type Screen =
  | 'landing'
  | 'auth'
  | 'dashboard'
  | 'quiz'
  | 'explore'
  | 'calm'
  | 'community'
  | 'profile';

type UserType = 'student' | 'teacher' | null;

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [userType, setUserType] = useState<UserType>(null);
  const [activeTab, setActiveTab] = useState('home');
  const [isLargeScreen, setIsLargeScreen] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsLargeScreen(window.innerWidth >= 1024);
    };
    
    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  const handleGetStarted = () => {
    setCurrentScreen('auth');
  };

  const handleLogin = (type: 'student' | 'teacher') => {
    setUserType(type);
    setCurrentScreen('dashboard');
    setActiveTab('home');
  };

  const handleBack = () => {
    setCurrentScreen('landing');
    setUserType(null);
  };

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    const tabScreenMap: Record<string, Screen> = {
      home: 'dashboard',
      explore: 'explore',
      calm: 'calm',
      community: 'community',
      profile: 'profile',
    };
    setCurrentScreen(tabScreenMap[tab] || 'dashboard');
  };

  const showBottomNav = currentScreen !== 'landing' && currentScreen !== 'auth' && currentScreen !== 'quiz' && !isLargeScreen;
  const showSideNav = currentScreen !== 'landing' && currentScreen !== 'auth' && isLargeScreen && userType;

  return (
    <div className="min-h-screen bg-white flex">
      {/* Side Navigation for Large Screens */}
      {showSideNav && (
        <SideNavigation
          activeSection={activeTab}
          onNavigate={handleTabChange}
          userType={userType}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 min-h-screen overflow-x-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {currentScreen === 'landing' && <LandingPage onGetStarted={handleGetStarted} />}
            
            {currentScreen === 'auth' && <AuthPage onLogin={handleLogin} onBack={handleBack} />}
            
            {currentScreen === 'dashboard' && userType === 'student' && (
              <StudentDashboard onNavigate={handleNavigate} />
            )}
            
            {currentScreen === 'dashboard' && userType === 'teacher' && <TeacherDashboard />}
            
            {currentScreen === 'quiz' && (
              <CareerQuiz onBack={() => setCurrentScreen('dashboard')} />
            )}
            
            {currentScreen === 'explore' && <ExploreOpportunities />}
            
            {currentScreen === 'calm' && <CalmZone />}
            
            {currentScreen === 'community' && <CommunityPage />}
            
            {currentScreen === 'profile' && <ProfilePage />}
          </motion.div>
        </AnimatePresence>

        {/* Bottom Navigation for Mobile/Tablet */}
        {showBottomNav && userType === 'student' && (
          <BottomNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        )}
      </div>
    </div>
  );
}
