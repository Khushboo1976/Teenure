import { useState } from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Heart, Share2, Users, TrendingUp, MessageSquare } from 'lucide-react';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import MessagingInterface from './MessagingInterface';

const posts = [
  {
    id: 1,
    author: 'Sarah Miller',
    avatar: 'https://images.unsplash.com/photo-1561065533-316e3142d586?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwcG9ydHJhaXQlMjBoYXBweXxlbnwxfHx8fDE3NjA1MjY3NjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    time: '2 hours ago',
    content: 'Just completed the UI/UX career quiz! Got 92% match for Product Designer. Feeling so motivated! 🎨✨',
    likes: 24,
    comments: 8,
    badge: 'Quiz Master',
  },
  {
    id: 2,
    author: 'James Chen',
    avatar: 'https://images.unsplash.com/photo-1561065533-316e3142d586?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwcG9ydHJhaXQlMjBoYXBweXxlbnwxfHx8fDE3NjA1MjY3NjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    time: '5 hours ago',
    content: 'Looking for study partners for the Web Development bootcamp. Anyone interested? 💻',
    likes: 15,
    comments: 12,
    badge: 'Active Learner',
  },
  {
    id: 3,
    author: 'Emma Wilson',
    avatar: 'https://images.unsplash.com/photo-1561065533-316e3142d586?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwcG9ydHJhaXQlMjBoYXBweXxlbnwxfHx8fDE3NjA1MjY3NjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    time: '1 day ago',
    content: 'The calm zone meditation sessions are amazing! Really helped me manage exam stress. Highly recommend! 🧘‍♀️',
    likes: 42,
    comments: 18,
    badge: 'Explorer',
  },
];

const trendingTopics = [
  { name: 'UI/UX Design', count: 234 },
  { name: 'Web Development', count: 189 },
  { name: 'Career Guidance', count: 156 },
  { name: 'Internships', count: 142 },
];

export default function CommunityPage() {
  const [showMessaging, setShowMessaging] = useState(false);

  if (showMessaging) {
    return <MessagingInterface />;
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] pb-20 lg:pb-8">
      {/* Header */}
      <div className="bg-white pt-12 lg:pt-8 pb-6 px-4 sm:px-6 lg:px-8 shadow-sm">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-gray-900 mb-2">Community</h1>
          <p className="text-gray-600">Connect with fellow explorers</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Trending Topics */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-[#FF7A00]" />
            <h3 className="text-gray-900">Trending Topics</h3>
          </div>
          <div className="space-y-2">
            {trendingTopics.map((topic, index) => (
              <button
                key={topic.name}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 transition-colors"
              >
                <span className="text-sm text-gray-900">#{topic.name}</span>
                <span className="text-xs text-gray-500">{topic.count} posts</span>
              </button>
            ))}
          </div>
        </div>

        {/* Feed */}
        <div className="space-y-4">
          {posts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-lg p-5"
            >
              {/* Post Header */}
              <div className="flex items-start gap-3 mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={post.avatar}
                    alt={post.author}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-gray-900">{post.author}</h4>
                    <Badge variant="secondary" className="text-xs">
                      {post.badge}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500">{post.time}</p>
                </div>
              </div>

              {/* Post Content */}
              <p className="text-gray-800 mb-4">{post.content}</p>

              {/* Post Actions */}
              <div className="flex items-center gap-6 pt-3 border-t border-gray-100">
                <button className="flex items-center gap-2 text-gray-600 hover:text-[#FF7A00] transition-colors">
                  <Heart className="w-5 h-5" />
                  <span className="text-sm">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 text-gray-600 hover:text-[#00AEEF] transition-colors">
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-sm">{post.comments}</span>
                </button>
                <button className="flex items-center gap-2 text-gray-600 hover:text-[#00B050] transition-colors ml-auto">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="fixed bottom-24 right-6 flex flex-col gap-3">
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, type: 'spring' }}
            onClick={() => setShowMessaging(true)}
            className="w-14 h-14 bg-[#002B5C] rounded-full shadow-2xl flex items-center justify-center text-white hover:shadow-3xl transition-shadow"
          >
            <MessageSquare className="w-6 h-6" />
          </motion.button>
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.6, type: 'spring' }}
            className="w-14 h-14 bg-gradient-to-br from-[#FF7A00] to-[#00AEEF] rounded-full shadow-2xl flex items-center justify-center text-white hover:shadow-3xl transition-shadow"
          >
            <Users className="w-6 h-6" />
          </motion.button>
        </div>
      </div>
    </div>
  );
}
