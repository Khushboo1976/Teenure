import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Filter, Bookmark, Calendar, MapPin, Users, ExternalLink, Briefcase, GraduationCap, Video } from 'lucide-react';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import workshopImg from 'figma:asset/f51a8c89bc1f2053dc9e3333c0eb85256a438664.png';

const opportunities = [
  {
    id: 1,
    title: 'UI/UX Design Internship',
    company: 'Tech Solutions Inc.',
    type: 'Internship',
    location: 'Remote',
    duration: '3 months',
    applicants: 24,
    image: 'https://images.unsplash.com/photo-1549399905-5d1bad747576?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwd29ya3NwYWNlJTIwbW9kZXJufGVufDF8fHx8MTc2MDUxOTk3N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    recommended: true,
    color: '#FF7A00',
  },
  {
    id: 2,
    title: 'Web Development Bootcamp',
    company: 'Code Academy',
    type: 'Course',
    location: 'Online',
    duration: '6 weeks',
    applicants: 156,
    image: 'https://images.unsplash.com/photo-1721468184185-214871ec4411?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBsZWFybmluZyUyMHN0dWRlbnR8ZW58MXx8fHwxNzYwNjEzNTQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    recommended: true,
    color: '#00AEEF',
  },
  {
    id: 3,
    title: 'Product Management Webinar',
    company: 'StartUp Hub',
    type: 'Webinar',
    location: 'Virtual',
    duration: '2 hours',
    applicants: 89,
    image: 'https://images.unsplash.com/photo-1549399905-5d1bad747576?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwd29ya3NwYWNlJTIwbW9kZXJufGVufDF8fHx8MTc2MDUxOTk3N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    recommended: false,
    color: '#00B050',
  },
  {
    id: 4,
    title: 'Data Science Summer Program',
    company: 'Analytics Corp',
    type: 'Event',
    location: 'Hybrid',
    duration: '8 weeks',
    applicants: 42,
    image: 'https://images.unsplash.com/photo-1721468184185-214871ec4411?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBsZWFybmluZyUyMHN0dWRlbnR8ZW58MXx8fHwxNzYwNjEzNTQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    recommended: true,
    color: '#00AEEF',
  },
];

const filterCategories = ['All', 'Internships', 'Webinars', 'Events', 'Courses'];

const featuredPrograms = [
  {
    id: 1,
    title: 'AI-Based Assessments',
    description: 'Take personalized assessments to discover careers aligned with your strengths and interests.',
    icon: Briefcase,
    image: 'https://images.unsplash.com/photo-1721468184185-214871ec4411?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBsZWFybmluZyUyMHN0dWRlbnR8ZW58MXx8fHwxNzYwNjEzNTQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 2,
    title: 'Peer Networking',
    description: 'Connect with peers from various educational backgrounds and expand your professional network.',
    icon: Users,
    image: 'https://images.unsplash.com/photo-1721468184185-214871ec4411?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBsZWFybmluZyUyMHN0dWRlbnR8ZW58MXx8fHwxNzYwNjEzNTQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 3,
    title: 'Mentorship Programs',
    description: 'Join mentorship programs to gain insights and guidance from experienced professionals.',
    icon: GraduationCap,
    image: 'https://images.unsplash.com/photo-1721468184185-214871ec4411?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBsZWFybmluZyUyMHN0dWRlbnR8ZW58MXx8fHwxNzYwNjEzNTQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
];

const liveWorkshops = [
  {
    id: 1,
    title: 'Live Workshops',
    description: 'Join our interactive live workshops to enhance your skills and knowledge. Our experts deliver real-world insights and practical approaches in various topics.',
    details: 'Our workshops cover a wide range of topics from technology to arts, providing a hands-on learning experience.',
    buttonText: 'Explore Workshops',
    image: workshopImg,
  },
  {
    id: 2,
    title: 'Industrial Visits',
    description: 'Experience industries firsthand with our organized visits. Understand the operational processes and meet professionals in their work environment.',
    details: 'Our visits offer a unique opportunity to connect with industry leaders and gain insights into various career paths.',
    buttonText: 'Schedule a Visit',
    image: workshopImg,
  },
];

export default function ExploreOpportunities() {
  const [selectedFilter, setSelectedFilter] = useState('All');
  const [bookmarked, setBookmarked] = useState<number[]>([]);

  const toggleBookmark = (id: number) => {
    setBookmarked((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-white pb-20 lg:pb-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-[#F5F5F5] to-white pt-12 lg:pt-16 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[#002B5C] mb-4"
          >
            Discover Your Future
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-gray-700 mb-8 max-w-2xl mx-auto"
          >
            Explore careers with AI-based assessments and connect with peers and mentors.
          </motion.p>
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-[#002B5C] text-white px-8 py-3 rounded hover:bg-[#003870] transition-colors"
          >
            Get Started
          </motion.button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Featured Programs */}
        <div className="mb-16">
          <div className="grid md:grid-cols-3 gap-8">
            {featuredPrograms.map((program, index) => {
              const Icon = program.icon;
              return (
                <motion.div
                  key={program.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="bg-[#F5F5F5] rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      src={program.image}
                      alt={program.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Icon className="w-6 h-6 text-[#002B5C]" />
                      <h3 className="text-[#002B5C]">{program.title}</h3>
                    </div>
                    <p className="text-sm text-gray-700">{program.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Live Workshops & Industrial Visits */}
        <div className="mb-16">
          <div className="space-y-8">
            {liveWorkshops.map((workshop, index) => (
              <motion.div
                key={workshop.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow"
              >
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="md:w-1/3">
                    <img
                      src={workshop.image}
                      alt={workshop.title}
                      className="w-full h-48 object-cover rounded"
                    />
                  </div>
                  <div className="md:w-2/3 space-y-4">
                    <h2 className="text-[#002B5C]">{workshop.title}</h2>
                    <p className="text-gray-700">{workshop.description}</p>
                    <p className="text-sm text-gray-600">{workshop.details}</p>
                    <button className="w-full md:w-auto bg-[#002B5C] text-white px-6 py-2 rounded hover:bg-[#003870] transition-colors">
                      {workshop.buttonText}
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Upcoming Workshops Section */}
        <div className="mb-12">
          <h2 className="text-[#002B5C] mb-6">Upcoming Workshops</h2>

          {/* Search Bar */}
          <div className="relative mb-6 max-w-2xl">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search opportunities..."
              className="pl-12 pr-4 h-12 rounded border-gray-300"
            />
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide mb-6">
            {filterCategories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedFilter(category)}
                className={`px-4 py-2 rounded whitespace-nowrap transition-all ${
                  selectedFilter === category
                    ? 'bg-[#002B5C] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
            <button className="p-2 rounded bg-gray-100 hover:bg-gray-200 transition-colors">
              <Filter className="w-5 h-5 text-gray-700" />
            </button>
          </div>

          {/* Workshop Cards in Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {opportunities.map((opportunity, index) => (
              <motion.div
                key={opportunity.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white border border-gray-200 rounded overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className="h-40 overflow-hidden">
                  <img
                    src={opportunity.image}
                    alt={opportunity.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="p-4">
                  <h4 className="text-[#002B5C] mb-2">{opportunity.title}</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    {opportunity.type === 'Internship' 
                      ? 'Learn the basics of digital marketing in this interactive workshop.'
                      : opportunity.type === 'Course'
                      ? 'Start your journey into coding with this beginner-friendly session.'
                      : opportunity.type === 'Webinar'
                      ? 'Develop leadership skills to excel in your career.'
                      : 'Gain hands-on experience in a professional environment.'}
                  </p>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{opportunity.duration}</span>
                    <Badge variant="secondary">{opportunity.type}</Badge>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
