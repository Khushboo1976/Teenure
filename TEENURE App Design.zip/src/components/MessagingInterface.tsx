import { useState } from 'react';
import { motion } from 'motion/react';
import {
  Search,
  Send,
  Paperclip,
  Image as ImageIcon,
  Smile,
  MoreVertical,
  Phone,
  Video,
  X,
  FileText,
  Download,
} from 'lucide-react';
import { Input } from './ui/input';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Message {
  id: number;
  sender: string;
  text: string;
  time: string;
  isMe: boolean;
  image?: string;
}

interface Conversation {
  id: number;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unread?: number;
  online?: boolean;
}

const conversations: Conversation[] = [
  {
    id: 1,
    name: 'Student Journey Begins',
    avatar: 'https://images.unsplash.com/photo-1561065533-316e3142d586?w=100',
    lastMessage: 'Ethan: Are you ready?',
    time: '',
    online: true,
  },
  {
    id: 2,
    name: 'Ava Thompson',
    avatar: 'https://images.unsplash.com/photo-1561065533-316e3142d586?w=100',
    lastMessage: "Ava: That's hilarious!",
    time: '',
    online: true,
  },
  {
    id: 3,
    name: 'Pablo Morandi',
    avatar: 'https://images.unsplash.com/photo-1561065533-316e3142d586?w=100',
    lastMessage: 'Pablo: This is amazing!',
    time: '12',
    online: false,
  },
  {
    id: 4,
    name: 'Olivia Hayes',
    avatar: 'https://images.unsplash.com/photo-1561065533-316e3142d586?w=100',
    lastMessage: 'Olivia: I found something',
    time: '1 hour',
    online: false,
  },
];

const messages: Message[] = [
  { id: 1, sender: 'Other', text: "I'm attending a career workshop today. Can't wait!", time: 'Thurs 9:11 AM', isMe: false },
  { id: 2, sender: 'Me', text: 'Exciting! Enjoy and learn lots.', time: '11:00 AM', isMe: true },
  { id: 3, sender: 'Other', text: 'Almost', time: '11:00 AM', isMe: false },
  { id: 4, sender: 'Other', text: 'Running a bit.', time: '11:00 AM', isMe: false },
  { id: 5, sender: 'Other', text: 'Oops.', time: '11:00 AM', isMe: false },
  { id: 6, sender: 'Me', text: "I'm already here. Where", time: '11:00 AM', isMe: true },
  { id: 7, sender: 'Other', text: "Just kidding. I'm", time: '11:00 AM', isMe: false },
  { id: 8, sender: 'Other', text: "You're", time: '11:00 AM', isMe: true, image: 'https://images.unsplash.com/photo-1606733572375-35620adc4a18?w=400' },
];

const careerResources = [
  { id: 1, name: 'Assessment.pdf', size: '2 MB', type: 'pdf' },
  { id: 2, name: 'Career Counseling', size: '5 MB', type: 'doc' },
  { id: 3, name: 'Essay - Chemistry', size: '500 KB', type: 'doc' },
  { id: 4, name: 'Assessment.pdf', size: '2 MB', type: 'pdf' },
];

export default function MessagingInterface() {
  const [selectedConversation, setSelectedConversation] = useState(conversations[1]);
  const [messageText, setMessageText] = useState('');
  const [showDetails, setShowDetails] = useState(true);

  return (
    <div className="h-screen bg-[#002B5C] flex">
      {/* Left Sidebar - Conversations List */}
      <div className="w-72 bg-[#002B5C] border-r border-white/10 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-white/10">
          <h2 className="text-white mb-4">Conversations</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search in conversations"
              className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {conversations.map((conv) => (
            <button
              key={conv.id}
              onClick={() => setSelectedConversation(conv)}
              className={`w-full p-4 flex items-start gap-3 hover:bg-white/5 transition-colors border-b border-white/5 ${
                selectedConversation.id === conv.id ? 'bg-white/10' : ''
              }`}
            >
              <div className="relative flex-shrink-0">
                <ImageWithFallback
                  src={conv.avatar}
                  alt={conv.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                {conv.online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#002B5C]" />
                )}
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-white text-sm">{conv.name}</h4>
                  {conv.unread && (
                    <span className="bg-[#FF7A00] text-white text-xs px-2 py-0.5 rounded-full">
                      {conv.unread}
                    </span>
                  )}
                </div>
                <p className="text-white/70 text-xs truncate">{conv.lastMessage}</p>
              </div>
              {conv.time && <span className="text-white/50 text-xs">{conv.time}</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-white">
        {/* Chat Header */}
        <div className="bg-[#002B5C] px-6 py-4 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="relative">
              <ImageWithFallback
                src={selectedConversation.avatar}
                alt={selectedConversation.name}
                className="w-10 h-10 rounded-full object-cover"
              />
              {selectedConversation.online && (
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#002B5C]" />
              )}
            </div>
            <div>
              <h3 className="text-white">{selectedConversation.name}</h3>
              <p className="text-white/70 text-xs">Currently available</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <Search className="w-5 h-5 text-white" />
            </button>
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <Phone className="w-5 h-5 text-white" />
            </button>
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <Video className="w-5 h-5 text-white" />
            </button>
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              {showDetails ? <X className="w-5 h-5 text-white" /> : <MoreVertical className="w-5 h-5 text-white" />}
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.isMe ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-md ${message.isMe ? 'order-2' : 'order-1'}`}>
                {message.id === 1 && (
                  <div className="text-center text-gray-500 text-xs mb-4">{message.time}</div>
                )}
                <div
                  className={`px-4 py-2 rounded-lg ${
                    message.isMe
                      ? 'bg-[#002B5C] text-white rounded-br-none'
                      : 'bg-white text-gray-900 rounded-bl-none shadow'
                  }`}
                >
                  {message.image ? (
                    <img src={message.image} alt="" className="rounded max-w-xs" />
                  ) : (
                    <p className="text-sm">{message.text}</p>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Message Input */}
        <div className="p-4 bg-white border-t border-gray-200">
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <Paperclip className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <ImageIcon className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <Smile className="w-5 h-5 text-gray-600" />
            </button>
            <Input
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Type a message"
              className="flex-1 rounded-full"
            />
            <button className="p-3 bg-[#002B5C] hover:bg-[#003870] rounded-full transition-colors">
              <Send className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      </div>

      {/* Right Sidebar - Conversation Details */}
      {showDetails && (
        <motion.div
          initial={{ x: 300 }}
          animate={{ x: 0 }}
          exit={{ x: 300 }}
          className="w-80 bg-[#002B5C] border-l border-white/10 overflow-y-auto"
        >
          <div className="p-6">
            <h3 className="text-white mb-6">Conversation details</h3>

            {/* Career Insights */}
            <div className="mb-6">
              <h4 className="text-white text-sm mb-3">Career insights (266)</h4>
              <div className="grid grid-cols-3 gap-2">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="aspect-square bg-white/10 rounded" />
                ))}
              </div>
            </div>

            {/* Career Resources */}
            <div className="mb-6">
              <h4 className="text-white text-sm mb-3">Career resources (4)</h4>
              <div className="space-y-2">
                {careerResources.map((resource) => (
                  <div
                    key={resource.id}
                    className="flex items-center gap-3 p-3 bg-white/5 rounded hover:bg-white/10 transition-colors"
                  >
                    <FileText className="w-5 h-5 text-white/70" />
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-xs truncate">{resource.name}</p>
                      <p className="text-white/50 text-xs">{resource.size}</p>
                    </div>
                    <button className="p-1 hover:bg-white/10 rounded">
                      <Download className="w-4 h-4 text-white/70" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Career Opportunities */}
            <div>
              <h4 className="text-white text-sm mb-3">Career opportunities</h4>
              <div className="space-y-2">
                <a
                  href="#"
                  className="block p-3 bg-white/5 rounded hover:bg-white/10 transition-colors"
                >
                  <p className="text-white text-xs mb-1">Professional profile</p>
                  <p className="text-white/50 text-xs truncate">https://linkedin.com/112abcdefzq</p>
                </a>
                <a
                  href="#"
                  className="block p-3 bg-white/5 rounded hover:bg-white/10 transition-colors"
                >
                  <p className="text-white text-xs mb-1">Skill-building game</p>
                  <p className="text-white/50 text-xs truncate">https://careergames.io/abcd123</p>
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
