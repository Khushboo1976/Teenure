import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Check, Star, Trophy, Sparkles } from 'lucide-react';
import { Progress } from './ui/progress';
import { Button } from './ui/button';

interface CareerQuizProps {
  onBack: () => void;
}

const quizQuestions = [
  {
    question: 'What excites you the most?',
    options: [
      { text: 'Building and creating things', icon: '🔨' },
      { text: 'Helping and teaching others', icon: '👥' },
      { text: 'Analyzing data and solving problems', icon: '📊' },
      { text: 'Expressing creativity through art', icon: '🎨' },
    ],
  },
  {
    question: 'Which environment do you prefer?',
    options: [
      { text: 'Fast-paced and dynamic', icon: '⚡' },
      { text: 'Structured and organized', icon: '📋' },
      { text: 'Creative and flexible', icon: '✨' },
      { text: 'Collaborative and social', icon: '🤝' },
    ],
  },
  {
    question: 'What type of projects interest you?',
    options: [
      { text: 'Technology and innovation', icon: '💻' },
      { text: 'Social impact and community', icon: '🌍' },
      { text: 'Design and aesthetics', icon: '🎭' },
      { text: 'Business and entrepreneurship', icon: '💼' },
    ],
  },
  {
    question: 'How do you like to spend your free time?',
    options: [
      { text: 'Learning new skills', icon: '📚' },
      { text: 'Creating content', icon: '🎬' },
      { text: 'Playing sports or being active', icon: '⚽' },
      { text: 'Experimenting with ideas', icon: '🔬' },
    ],
  },
];

export default function CareerQuiz({ onBack }: CareerQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);

  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = [...selectedAnswers, optionIndex];
    setSelectedAnswers(newAnswers);

    if (currentQuestion < quizQuestions.length - 1) {
      setTimeout(() => {
        setCurrentQuestion(currentQuestion + 1);
      }, 300);
    } else {
      setTimeout(() => {
        setShowResults(true);
      }, 300);
    }
  };

  const careerSuggestions = [
    {
      title: 'UI/UX Designer',
      match: '92%',
      description: 'Create beautiful and functional digital experiences',
      color: '#FF7A00',
    },
    {
      title: 'Software Developer',
      match: '88%',
      description: 'Build innovative applications and solutions',
      color: '#00AEEF',
    },
    {
      title: 'Product Manager',
      match: '85%',
      description: 'Lead product development and strategy',
      color: '#00B050',
    },
  ];

  if (showResults) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#FF7A00]/10 to-white pb-20 lg:pb-8">
        <div className="pt-12 lg:pt-8 px-4 sm:px-6 lg:px-8 max-w-2xl mx-auto">
          <button
            onClick={onBack}
            className="mb-6 p-2 rounded-full hover:bg-white/50 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>

          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', duration: 0.6 }}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-[#FF7A00] to-[#00AEEF] rounded-full mb-4 shadow-2xl">
              <Trophy className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-gray-900 mb-2">Great Job! 🎉</h1>
            <p className="text-gray-600">Your career journey starts here!</p>
          </motion.div>

          <div className="space-y-4">
            <h3 className="text-gray-900">Your Top Career Matches</h3>
            {careerSuggestions.map((career, index) => (
              <motion.div
                key={career.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="bg-white rounded-2xl p-5 shadow-lg"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="text-gray-900 mb-1">{career.title}</h4>
                    <p className="text-sm text-gray-600">{career.description}</p>
                  </div>
                  <div
                    className="px-3 py-1 rounded-full text-sm text-white"
                    style={{ backgroundColor: career.color }}
                  >
                    {career.match}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  <Star className="w-4 h-4 text-gray-300" />
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-8 space-y-3">
            <Button className="w-full bg-[#FF7A00] hover:bg-[#FF7A00]/90 text-white rounded-xl h-12">
              Explore Opportunities
            </Button>
            <Button
              variant="outline"
              className="w-full rounded-xl h-12 border-gray-300"
              onClick={onBack}
            >
              Back to Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FF7A00]/10 to-white pb-20 lg:pb-8">
      <div className="pt-12 lg:pt-8 px-4 sm:px-6 lg:px-8 max-w-2xl mx-auto">
        <button
          onClick={onBack}
          className="mb-6 p-2 rounded-full hover:bg-white/50 transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700" />
        </button>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">
              Question {currentQuestion + 1} of {quizQuestions.length}
            </span>
            <div className="flex gap-1">
              {Array.from({ length: quizQuestions.length }).map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className={`w-2 h-2 rounded-full ${
                    i < currentQuestion ? 'bg-[#FF7A00]' : i === currentQuestion ? 'bg-[#FF7A00]/50' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="bg-gradient-to-br from-white to-[#FF7A00]/5 rounded-3xl p-8 shadow-2xl mb-8"
          >
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-6 h-6 text-[#FF7A00]" />
              <span className="text-sm text-[#FF7A00]">Career Quiz</span>
            </div>
            <h2 className="text-gray-900 mb-6">{quizQuestions[currentQuestion].question}</h2>
          </motion.div>
        </AnimatePresence>

        {/* Options */}
        <div className="space-y-3">
          {quizQuestions[currentQuestion].options.map((option, index) => (
            <motion.button
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.05 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleAnswer(index)}
              className="w-full bg-white rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all text-left group"
            >
              <div className="flex items-center gap-4">
                <div className="text-3xl">{option.icon}</div>
                <div className="flex-1 text-gray-900">{option.text}</div>
                <div className="w-6 h-6 rounded-full border-2 border-gray-300 group-hover:border-[#FF7A00] transition-colors" />
              </div>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
