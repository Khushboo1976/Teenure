import { motion } from 'motion/react';
import {
  BookOpen,
  Trophy,
  Target,
  Sparkles,
  TrendingUp,
  Award,
  Clock,
  Zap,
} from 'lucide-react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface StudentDashboardProps {
  onNavigate: (screen: string) => void;
}

export default function StudentDashboard({ onNavigate }: StudentDashboardProps) {
  const isLargeScreen = typeof window !== 'undefined' && window.innerWidth >= 1024;
  const badges = [
    { icon: Trophy, name: 'Quiz Master', color: '#FF7A00' },
    { icon: Target, name: 'Goal Setter', color: '#00B050' },
    { icon: Sparkles, name: 'Explorer', color: '#00AEEF' },
  ];

  const quickActions = [
    {
      id: 'quiz',
      title: 'Career Quiz',
      subtitle: 'Discover your path',
      icon: BookOpen,
      color: '#FF7A00',
      bgColor: 'bg-[#FF7A00]/10',
    },
    {
      id: 'explore',
      title: 'Opportunities',
      subtitle: 'Find internships',
      icon: TrendingUp,
      color: '#00B050',
      bgColor: 'bg-[#00B050]/10',
    },
    {
      id: 'calm',
      title: 'Calm Zone',
      subtitle: 'Take a break',
      icon: Sparkles,
      color: '#00AEEF',
      bgColor: 'bg-[#00AEEF]/10',
    },
  ];

  const recentActivities = [
    { title: 'Completed Career Quiz', time: '2 hours ago', icon: Award },
    { title: 'Saved UI/UX Webinar', time: 'Yesterday', icon: BookOpen },
    { title: 'Meditation Session', time: '2 days ago', icon: Sparkles },
  ];

  return (
    <div className="min-h-screen bg-[#F5F5F5] pb-20 lg:pb-8">
      {/* Header */}
      <div className="bg-[#002B5C] pt-12 lg:pt-8 pb-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-white mb-1">Welcome back,</h2>
              <h1 className="text-white">Alex! 👋</h1>
            </div>
            <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-white shadow-lg">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1561065533-316e3142d586?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwcG9ydHJhaXQlMjBoYXBweXxlbnwxfHx8fDE3NjA1MjY3NjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center">
              <Zap className="w-5 h-5 text-white mx-auto mb-1" />
              <div className="text-white">245</div>
              <div className="text-xs text-white/80">Points</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center">
              <Award className="w-5 h-5 text-white mx-auto mb-1" />
              <div className="text-white">12</div>
              <div className="text-xs text-white/80">Badges</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center">
              <Target className="w-5 h-5 text-white mx-auto mb-1" />
              <div className="text-white">8</div>
              <div className="text-xs text-white/80">Goals</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-4">
        {/* Quick Actions */}
        <div className="bg-white rounded-2xl shadow-lg p-4 sm:p-5 mb-6">
          <h3 className="mb-4 text-gray-900">Quick Actions</h3>
          <div className="grid grid-cols-3 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <motion.button
                  key={action.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onNavigate(action.id)}
                  className="flex flex-col items-center gap-2 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className={`w-12 h-12 ${action.bgColor} rounded-xl flex items-center justify-center`}>
                    <Icon className="w-6 h-6" style={{ color: action.color }} />
                  </div>
                  <div className="text-center">
                    <div className="text-xs text-gray-900">{action.title}</div>
                    <div className="text-[10px] text-gray-500">{action.subtitle}</div>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
        
        {/* Progress */}
        <div className="bg-white rounded-2xl shadow-lg p-4 sm:p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-gray-900">Your Progress</h3>
            <Badge className="bg-[#00B050] text-white">On Track</Badge>
          </div>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-700">Career Exploration</span>
                <span className="text-gray-500">75%</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-700">Skills Development</span>
                <span className="text-gray-500">60%</span>
              </div>
              <Progress value={60} className="h-2" />
            </div>
          </div>
        </div>

        {/* Badges */}
        <div className="bg-white rounded-2xl shadow-lg p-4 sm:p-5">
          <h3 className="mb-4 text-gray-900">Recent Badges</h3>
          <div className="flex gap-3">
            {badges.map((badge, index) => {
              const Icon = badge.icon;
              return (
                <motion.div
                  key={badge.name}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.1, type: 'spring' }}
                  className="flex flex-col items-center gap-2"
                >
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center shadow-lg"
                    style={{ backgroundColor: `${badge.color}20` }}
                  >
                    <Icon className="w-8 h-8" style={{ color: badge.color }} />
                  </div>
                  <span className="text-xs text-gray-700 text-center">{badge.name}</span>
                </motion.div>
              );
            })}
          </div>
        </div>

        </div>
        
        {/* Recent Activity */}
        <div className="bg-white rounded-2xl shadow-lg p-4 sm:p-5 mb-6">
          <h3 className="mb-4 text-gray-900">Recent Activity</h3>
          <div className="space-y-3">
            {recentActivities.map((activity, index) => {
              const Icon = activity.icon;
              return (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#F5F5F5] rounded-xl flex items-center justify-center">
                    <Icon className="w-5 h-5 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-gray-900">{activity.title}</div>
                    <div className="text-xs text-gray-500 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {activity.time}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
