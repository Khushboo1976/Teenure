import { motion } from 'motion/react';
import {
  Users,
  BookOpen,
  TrendingUp,
  Award,
  Plus,
  ChevronRight,
  BarChart3,
  Calendar,
  Clock,
} from 'lucide-react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

const stats = [
  { icon: Users, label: 'Total Students', value: '156', change: '+12', color: '#FF7A00' },
  { icon: BookOpen, label: 'Active Courses', value: '8', change: '+2', color: '#00B050' },
  { icon: Award, label: 'Completed Quizzes', value: '342', change: '+45', color: '#00AEEF' },
  { icon: TrendingUp, label: 'Avg. Engagement', value: '84%', change: '+5%', color: '#FF7A00' },
];

const recentActivity = [
  {
    student: 'Sarah Miller',
    action: 'Completed Career Quiz',
    score: '92%',
    time: '2 hours ago',
  },
  {
    student: 'James Chen',
    action: 'Applied for Internship',
    score: null,
    time: '4 hours ago',
  },
  {
    student: 'Emma Wilson',
    action: 'Completed Web Dev Course',
    score: '88%',
    time: '1 day ago',
  },
  {
    student: 'Lucas Brown',
    action: 'Joined Design Webinar',
    score: null,
    time: '2 days ago',
  },
];

const upcomingEvents = [
  {
    title: 'Product Management Workshop',
    date: 'Oct 20, 2025',
    time: '2:00 PM',
    attendees: 24,
  },
  {
    title: 'Career Guidance Session',
    date: 'Oct 22, 2025',
    time: '10:00 AM',
    attendees: 45,
  },
];

export default function TeacherDashboard() {
  return (
    <div className="min-h-screen bg-[#F5F5F5] pb-20 lg:pb-8">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#00B050] to-[#00B050]/80 pt-12 lg:pt-8 pb-8 px-4 sm:px-6 lg:px-8 rounded-b-[2rem] lg:rounded-b-none">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-white mb-1">Welcome back,</h2>
              <h1 className="text-white">Ms. Anderson 👋</h1>
            </div>
            <button className="px-4 py-2 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-xl text-white transition-colors flex items-center gap-2">
              <Plus className="w-5 h-5" />
              Add Course
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-4">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-5 shadow-lg"
              >
                <div
                  className="w-10 h-10 rounded-xl mb-3 flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}20` }}
                >
                  <Icon className="w-5 h-5" style={{ color: stat.color }} />
                </div>
                <div className="text-2xl text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600 mb-2">{stat.label}</div>
                <div className="text-xs text-green-600 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  {stat.change}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-6">
          <h3 className="text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <button className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#FF7A00]/10 hover:bg-[#FF7A00]/20 transition-colors">
              <Plus className="w-6 h-6 text-[#FF7A00]" />
              <span className="text-sm text-gray-900">Add Opportunity</span>
            </button>
            <button className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#00B050]/10 hover:bg-[#00B050]/20 transition-colors">
              <BookOpen className="w-6 h-6 text-[#00B050]" />
              <span className="text-sm text-gray-900">Create Quiz</span>
            </button>
            <button className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#00AEEF]/10 hover:bg-[#00AEEF]/20 transition-colors">
              <BarChart3 className="w-6 h-6 text-[#00AEEF]" />
              <span className="text-sm text-gray-900">View Analytics</span>
            </button>
            <button className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#FF7A00]/10 hover:bg-[#FF7A00]/20 transition-colors">
              <Calendar className="w-6 h-6 text-[#FF7A00]" />
              <span className="text-sm text-gray-900">Schedule Event</span>
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Recent Activity */}
          <div className="bg-white rounded-2xl shadow-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-900">Recent Activity</h3>
              <button className="text-sm text-[#FF7A00]">View All</button>
            </div>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 pb-4 border-b last:border-b-0 border-gray-100"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF7A00] to-[#00AEEF] flex items-center justify-center text-white flex-shrink-0">
                    {activity.student.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-gray-900">{activity.student}</div>
                    <div className="text-xs text-gray-600">{activity.action}</div>
                    <div className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {activity.time}
                    </div>
                  </div>
                  {activity.score && (
                    <Badge className="bg-[#00B050] text-white">{activity.score}</Badge>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Events */}
          <div className="bg-white rounded-2xl shadow-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-900">Upcoming Events</h3>
              <button className="text-sm text-[#FF7A00]">View Calendar</button>
            </div>
            <div className="space-y-4">
              {upcomingEvents.map((event, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-[#FF7A00]/10 to-[#00AEEF]/10 rounded-xl p-4"
                >
                  <h4 className="text-gray-900 mb-2">{event.title}</h4>
                  <div className="flex items-center gap-4 text-xs text-gray-600 mb-3">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {event.date}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {event.time}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-gray-600">
                      <Users className="w-4 h-4 inline mr-1" />
                      {event.attendees} registered
                    </div>
                    <button className="text-sm text-[#FF7A00] flex items-center gap-1">
                      Manage
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Course Performance */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mt-6">
          <h3 className="text-gray-900 mb-4">Course Performance</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-900">UI/UX Design Fundamentals</span>
                <span className="text-sm text-gray-600">92% completion</span>
              </div>
              <Progress value={92} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-900">Web Development Bootcamp</span>
                <span className="text-sm text-gray-600">78% completion</span>
              </div>
              <Progress value={78} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-900">Product Management Basics</span>
                <span className="text-sm text-gray-600">85% completion</span>
              </div>
              <Progress value={85} className="h-2" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
