import { motion } from 'motion/react';
import { Play, Heart, Sparkles, Wind, Moon, Sun } from 'lucide-react';

const categories = [
  { id: 'meditation', title: 'Meditation', icon: Sparkles, color: '#00AEEF' },
  { id: 'motivation', title: 'Motivation', icon: Heart, color: '#FF7A00' },
  { id: 'exercises', title: 'Exercises', icon: Wind, color: '#00B050' },
];

const calmContent = [
  {
    title: 'Morning Mindfulness',
    duration: '10 min',
    category: 'meditation',
    plays: '12.5k',
    image: 'https://images.unsplash.com/photo-1606733572375-35620adc4a18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwY2FsbSUyMG5hdHVyZXxlbnwxfHx8fDE3NjA2MTM1NDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    icon: Sun,
  },
  {
    title: 'Breathing Exercise',
    duration: '5 min',
    category: 'exercises',
    plays: '8.3k',
    image: 'https://images.unsplash.com/photo-1606733572375-35620adc4a18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwY2FsbSUyMG5hdHVyZXxlbnwxfHx8fDE3NjA2MTM1NDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    icon: Wind,
  },
  {
    title: 'You Can Do This',
    duration: '3 min',
    category: 'motivation',
    plays: '15.2k',
    image: 'https://images.unsplash.com/photo-1606733572375-35620adc4a18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwY2FsbSUyMG5hdHVyZXxlbnwxfHx8fDE3NjA2MTM1NDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    icon: Heart,
  },
  {
    title: 'Evening Relaxation',
    duration: '15 min',
    category: 'meditation',
    plays: '9.7k',
    image: 'https://images.unsplash.com/photo-1606733572375-35620adc4a18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwY2FsbSUyMG5hdHVyZXxlbnwxfHx8fDE3NjA2MTM1NDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    icon: Moon,
  },
];

export default function CalmZone() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#00AEEF]/10 to-white pb-20 lg:pb-8">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#00AEEF] to-[#00AEEF]/80 pt-12 lg:pt-8 pb-8 px-4 sm:px-6 lg:px-8 rounded-b-[2rem] lg:rounded-b-none">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Sparkles className="w-16 h-16 text-white mx-auto mb-4" />
          </motion.div>
          <h1 className="text-white mb-2">Calm Zone</h1>
          <p className="text-white/90">Take a deep breath, explore your mind</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Categories */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <motion.button
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-white rounded-2xl p-4 shadow-lg hover:shadow-xl transition-all"
              >
                <div
                  className="w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center"
                  style={{ backgroundColor: `${category.color}20` }}
                >
                  <Icon className="w-6 h-6" style={{ color: category.color }} />
                </div>
                <div className="text-sm text-gray-900">{category.title}</div>
              </motion.button>
            );
          })}
        </div>

        {/* Featured */}
        <div className="mb-8">
          <h3 className="text-gray-900 mb-4">Featured</h3>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="relative rounded-3xl overflow-hidden shadow-2xl"
          >
            <div className="relative h-56">
              <img
                src="https://images.unsplash.com/photo-1606733572375-35620adc4a18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwY2FsbSUyMG5hdHVyZXxlbnwxfHx8fDE3NjA2MTM1NDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Featured meditation"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="mb-2">Daily Meditation Practice</h3>
                <p className="text-sm text-white/90 mb-4">20 min • Guided meditation</p>
                <button className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 flex items-center justify-center transition-colors">
                  <Play className="w-6 h-6 text-white fill-white ml-1" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Content Grid */}
        <div className="mb-6">
          <h3 className="text-gray-900 mb-4">Recommended</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {calmContent.map((content, index) => {
              const Icon = content.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="relative h-32">
                    <img
                      src={content.image}
                      alt={content.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/30 backdrop-blur-sm hover:bg-white/40 flex items-center justify-center transition-colors">
                      <Play className="w-5 h-5 text-white fill-white ml-0.5" />
                    </button>
                    <div className="absolute top-2 right-2">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <div className="p-4">
                    <h4 className="text-sm text-gray-900 mb-1">{content.title}</h4>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{content.duration}</span>
                      <span>{content.plays} plays</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Quick Tips */}
        <div className="bg-gradient-to-br from-[#00AEEF]/10 to-white rounded-2xl p-6 mb-6">
          <h3 className="text-gray-900 mb-4">Quick Tips</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-[#00AEEF]/20 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-[#00AEEF]" />
              </div>
              <div>
                <p className="text-sm text-gray-900">Take 5 deep breaths when feeling stressed</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-[#00AEEF]/20 flex items-center justify-center flex-shrink-0">
                <Heart className="w-4 h-4 text-[#00AEEF]" />
              </div>
              <div>
                <p className="text-sm text-gray-900">Practice gratitude daily for better mental health</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-[#00AEEF]/20 flex items-center justify-center flex-shrink-0">
                <Wind className="w-4 h-4 text-[#00AEEF]" />
              </div>
              <div>
                <p className="text-sm text-gray-900">Stay hydrated throughout the day</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
