import { motion } from 'motion/react';
import logo from 'figma:asset/b035f90100d0799d5553ffaaeaa0af800744857d.png';

interface LandingPageProps {
  onGetStarted: () => void;
}

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-white to-[#F5F5F5] px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center w-full max-w-sm sm:max-w-md lg:max-w-lg"
      >
        {/* Logo */}
        <motion.div
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-8 sm:mb-12"
        >
          <img 
            src={logo} 
            alt="TEENURE Logo" 
            className="w-48 h-48 sm:w-64 sm:h-64 lg:w-80 lg:h-80 mx-auto object-contain"
          />
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onGetStarted}
          className="w-full sm:w-auto sm:px-12 bg-[#FF7A00] text-white py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all"
        >
          Get Started
        </motion.button>
      </motion.div>
    </div>
  );
}
