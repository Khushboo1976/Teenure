import { useState } from 'react';
import { motion } from 'motion/react';
import { GraduationCap, User, ArrowLeft } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface AuthPageProps {
  onLogin: (userType: 'student' | 'teacher') => void;
  onBack: () => void;
}

export default function AuthPage({ onLogin, onBack }: AuthPageProps) {
  const [mode, setMode] = useState<'select' | 'login' | 'signup'>('select');
  const [userType, setUserType] = useState<'student' | 'teacher'>('student');

  const handleUserTypeSelect = (type: 'student' | 'teacher') => {
    setUserType(type);
    setMode('login');
  };

  const handleLogin = () => {
    onLogin(userType);
  };

  if (mode === 'select') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-white to-[#F5F5F5] px-4 sm:px-6 lg:px-8">
        <button
          onClick={onBack}
          className="absolute top-6 left-6 p-2 rounded-full hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700" />
        </button>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center max-w-md w-full"
        >
          <h2 className="mb-2 text-gray-900">Welcome!</h2>
          <p className="mb-12 text-gray-600">Choose your role to continue</p>

          <div className="space-y-4">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleUserTypeSelect('student')}
              className="w-full bg-white border-2 border-[#00AEEF] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-[#00AEEF]/10 flex items-center justify-center">
                  <GraduationCap className="w-8 h-8 text-[#00AEEF]" />
                </div>
                <div className="text-left flex-1">
                  <h3 className="text-gray-900">Student</h3>
                  <p className="text-sm text-gray-600">Explore opportunities and grow</p>
                </div>
              </div>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleUserTypeSelect('teacher')}
              className="w-full bg-white border-2 border-[#00B050] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-[#00B050]/10 flex items-center justify-center">
                  <User className="w-8 h-8 text-[#00B050]" />
                </div>
                <div className="text-left flex-1">
                  <h3 className="text-gray-900">Teacher / Admin</h3>
                  <p className="text-sm text-gray-600">Manage and guide students</p>
                </div>
              </div>
            </motion.button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-white to-[#F5F5F5] px-4 sm:px-6 lg:px-8">
      <button
        onClick={() => setMode('select')}
        className="absolute top-6 left-6 p-2 rounded-full hover:bg-gray-100 transition-colors"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
      </button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <h2 className="mb-2 text-gray-900">
            {mode === 'login' ? 'Welcome Back' : 'Create Account'}
          </h2>
          <p className="text-gray-600">
            Sign {mode === 'login' ? 'in' : 'up'} as a {userType}
          </p>
        </div>

        <div className="bg-white rounded-3xl p-8 shadow-lg space-y-4">
          <div className="space-y-2">
            <label className="text-sm text-gray-700">Email</label>
            <Input
              type="email"
              placeholder="your@email.com"
              className="rounded-xl border-gray-200"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-700">Password</label>
            <Input
              type="password"
              placeholder="••••••••"
              className="rounded-xl border-gray-200"
            />
          </div>

          {mode === 'signup' && (
            <div className="space-y-2">
              <label className="text-sm text-gray-700">Full Name</label>
              <Input
                type="text"
                placeholder="Your name"
                className="rounded-xl border-gray-200"
              />
            </div>
          )}

          <Button
            onClick={handleLogin}
            className="w-full bg-[#FF7A00] hover:bg-[#FF7A00]/90 text-white rounded-xl h-12 mt-6"
          >
            {mode === 'login' ? 'Sign In' : 'Create Account'}
          </Button>

          <p className="text-center text-sm text-gray-600 mt-4">
            {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
            <button
              onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
              className="text-[#FF7A00]"
            >
              {mode === 'login' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
