import { motion } from 'motion/react';
import {
  User,
  Settings,
  Trophy,
  Award,
  Target,
  BookOpen,
  Zap,
  Star,
  ChevronRight,
} from 'lucide-react';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

const achievements = [
  { icon: Trophy, title: 'Quiz Master', date: 'Oct 2025', color: '#FF7A00' },
  { icon: Target, title: 'Goal Setter', date: 'Oct 2025', color: '#00B050' },
  { icon: Award, title: 'Active Learner', date: 'Sep 2025', color: '#00AEEF' },
  { icon: Star, title: 'First Step', date: 'Sep 2025', color: '#FF7A00' },
  { icon: Zap, title: 'Quick Starter', date: 'Sep 2025', color: '#00B050' },
  { icon: BookOpen, title: 'Knowledge Seeker', date: 'Aug 2025', color: '#00AEEF' },
];

const interests = [
  'UI/UX Design',
  'Web Development',
  'Product Management',
  'Data Science',
  'Digital Marketing',
];

const menuItems = [
  { icon: User, title: 'Edit Profile', color: '#FF7A00' },
  { icon: BookOpen, title: 'Saved Opportunities', color: '#00B050' },
  { icon: Trophy, title: 'Achievements', color: '#00AEEF' },
  { icon: Settings, title: 'Settings', color: '#666' },
];

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-[#F5F5F5] pb-20 lg:pb-8">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#00AEEF] to-[#FF7A00] pt-12 lg:pt-8 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-end mb-4">
            <button className="p-2 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 transition-colors">
              <Settings className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16">
        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-2xl p-6 mb-6"
        >
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white shadow-lg mb-4 -mt-16">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1561065533-316e3142d586?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwcG9ydHJhaXQlMjBoYXBweXxlbnwxfHx8fDE3NjA1MjY3NjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
            <h2 className="text-gray-900 mb-1">Alex Johnson</h2>
            <p className="text-gray-600 mb-4">Student • Grade 11</p>
            <Badge className="bg-gradient-to-r from-[#FF7A00] to-[#00AEEF] text-white border-0">
              Level 5 Explorer
            </Badge>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-[#FF7A00]/10 mx-auto mb-2 flex items-center justify-center">
                <Zap className="w-6 h-6 text-[#FF7A00]" />
              </div>
              <div className="text-gray-900">245</div>
              <div className="text-xs text-gray-600">Points</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-[#00B050]/10 mx-auto mb-2 flex items-center justify-center">
                <Award className="w-6 h-6 text-[#00B050]" />
              </div>
              <div className="text-gray-900">12</div>
              <div className="text-xs text-gray-600">Badges</div>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-[#00AEEF]/10 mx-auto mb-2 flex items-center justify-center">
                <Target className="w-6 h-6 text-[#00AEEF]" />
              </div>
              <div className="text-gray-900">8</div>
              <div className="text-xs text-gray-600">Goals</div>
            </div>
          </div>
        </motion.div>

        {/* Interests */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-6">
          <h3 className="text-gray-900 mb-4">Interests</h3>
          <div className="flex flex-wrap gap-2">
            {interests.map((interest, index) => (
              <motion.div
                key={interest}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <Badge variant="secondary" className="px-3 py-1">
                  {interest}
                </Badge>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-900">Achievements</h3>
            <button className="text-sm text-[#FF7A00]">View All</button>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {achievements.slice(0, 6).map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.3 + index * 0.05, type: 'spring' }}
                  className="flex flex-col items-center gap-2"
                >
                  <div
                    className="w-14 h-14 rounded-full flex items-center justify-center shadow-lg"
                    style={{ backgroundColor: `${achievement.color}20` }}
                  >
                    <Icon className="w-6 h-6" style={{ color: achievement.color }} />
                  </div>
                  <span className="text-xs text-gray-700 text-center">
                    {achievement.title}
                  </span>
                  <span className="text-[10px] text-gray-500">{achievement.date}</span>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Menu */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={index}
                className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors border-b last:border-b-0 border-gray-100"
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ backgroundColor: `${item.color}20` }}
                >
                  <Icon className="w-5 h-5" style={{ color: item.color }} />
                </div>
                <span className="flex-1 text-left text-gray-900">{item.title}</span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            );
          })}
        </div>

        {/* Logout */}
        <button className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-4 rounded-2xl transition-colors mb-6">
          Log Out
        </button>
      </div>
    </div>
  );
}
