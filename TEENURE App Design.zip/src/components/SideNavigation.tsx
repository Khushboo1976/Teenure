import { useState } from 'react';
import { 
  Compass, 
  BookOpen, 
  Users, 
  TrendingUp, 
  BarChart3, 
  ChevronDown,
  Home,
  Cloud,
  User,
  Menu,
  X
} from 'lucide-react';
import logo from 'figma:asset/b035f90100d0799d5553ffaaeaa0af800744857d.png';

interface SideNavigationProps {
  activeSection: string;
  onNavigate: (section: string) => void;
  userType: 'student' | 'teacher';
}

export default function SideNavigation({ activeSection, onNavigate, userType }: SideNavigationProps) {
  const [expandedSection, setExpandedSection] = useState<string | null>('discover');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const studentSections = [
    {
      id: 'home',
      title: 'Home',
      icon: Home,
      items: null,
    },
    {
      id: 'discover',
      title: 'Discover',
      icon: Compass,
      items: [
        { id: 'explore', label: 'Explore', icon: Compass },
        { id: 'quiz', label: 'Career Paths', icon: BookOpen },
        { id: 'community', label: 'Network', icon: Users },
      ],
    },
    {
      id: 'wellness',
      title: 'Wellness',
      icon: Cloud,
      items: [
        { id: 'calm', label: 'Calm Zone', icon: Cloud },
      ],
    },
    {
      id: 'profile',
      title: 'Profile',
      icon: User,
      items: null,
    },
  ];

  const teacherSections = [
    {
      id: 'home',
      title: 'Dashboard',
      icon: Home,
      items: null,
    },
    {
      id: 'students',
      title: 'Students',
      icon: Users,
      items: [
        { id: 'progress', label: 'Progress', icon: TrendingUp },
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
      ],
    },
  ];

  const sections = userType === 'student' ? studentSections : teacherSections;

  const toggleSection = (sectionId: string) => {
    setExpandedSection(expandedSection === sectionId ? null : sectionId);
  };

  const handleNavClick = (itemId: string) => {
    onNavigate(itemId);
    setIsMobileMenuOpen(false);
  };

  const NavContent = () => (
    <>
      <div className="p-4 sm:p-6 border-b border-white/10">
        <img src={logo} alt="TEENURE" className="h-12 sm:h-16 mx-auto" />
      </div>

      <nav className="flex-1 p-3 sm:p-4 overflow-y-auto">
        {sections.map((section) => {
          const Icon = section.icon;
          const isExpanded = expandedSection === section.id;
          const isActive = activeSection === section.id || 
            (section.items && section.items.some(item => item.id === activeSection));

          return (
            <div key={section.id} className="mb-1 sm:mb-2">
              <button
                onClick={() => {
                  if (section.items) {
                    toggleSection(section.id);
                  } else {
                    handleNavClick(section.id);
                  }
                }}
                className={`w-full flex items-center justify-between px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-white text-[#002B5C]'
                    : 'text-white/80 hover:bg-white/10 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2 sm:gap-3">
                  <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="text-sm sm:text-base">{section.title}</span>
                </div>
                {section.items && (
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${
                      isExpanded ? 'rotate-180' : ''
                    }`}
                  />
                )}
              </button>

              {section.items && isExpanded && (
                <div className="mt-1 ml-4 sm:ml-6 space-y-1">
                  {section.items.map((item) => {
                    const ItemIcon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleNavClick(item.id)}
                        className={`w-full flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2 rounded-lg transition-colors text-sm ${
                          activeSection === item.id
                            ? 'bg-white/20 text-white'
                            : 'text-white/70 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <ItemIcon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/10">
        <p className="text-white/60 text-xs text-center">
          © 2025 TEENURE
        </p>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-[#002B5C] text-white rounded-lg shadow-lg"
      >
        {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:sticky top-0 left-0 h-screen bg-[#002B5C] flex flex-col z-40
          transition-transform duration-300 ease-in-out
          w-64 sm:w-72
          ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <NavContent />
      </aside>
    </>
  );
}
